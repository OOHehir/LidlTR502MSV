"use strict";

var self = module.exports = {
	
	init: function(){
		
	},
	deleted: function(){
		
	},
	capabilities: function(){
		
	}
	
}