# Lidl TR-502MSV

This app is a post from the https://github.com/athombv/nl.aldi

Its fairly rough implementation but works for me! I haven't implemented:
* The dimmer socket (RC-710DX) as it's triac based & appears to perform poorly with all devices except incandescent lamps.
* DIM/ Bright
* All off/ all on

If anyone wishes to contribute or improve please feel free!




